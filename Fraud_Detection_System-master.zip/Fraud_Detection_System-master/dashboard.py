from dash import Dash, html, dcc
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px

# Load data
df = pd.read_csv("synthetic_data.csv")

# Initialize the app with Bootstrap theme
app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
app.title = "Admin Dashboard - Fraud Detection"

# Fraud Trends
fraud_counts = df['label'].value_counts()
fraud_data = pd.DataFrame({
    "Type": ["Non-Fraudulent", "Fraudulent"],
    "Count": fraud_counts.values
})
fraud_trend_chart = px.bar(
    fraud_data, x="Type", y="Count",
    title="Fraud vs Non-Fraud Transactions",
    color="Type",
    color_discrete_map={"Non-Fraudulent": "green", "Fraudulent": "red"},
    text="Count"
)
fraud_trend_chart.update_layout(title_x=0.5)

# Transaction Amount Distribution
amount_histogram = px.histogram(
    df, x="amount", color="label",
    nbins=30, title="Transaction Amount Distribution",
    color_discrete_map={0: "blue", 1: "orange"}
)
amount_histogram.update_layout(title_x=0.5)

# User Insights: Pie Chart for Device Distribution
device_distribution = df['device'].value_counts()
device_data = pd.DataFrame({
    "Device": device_distribution.index,
    "Count": device_distribution.values
})
device_pie_chart = px.pie(
    device_data, names="Device", values="Count",
    title="Device Usage Distribution"
)
device_pie_chart.update_traces(textinfo="percent+label")
device_pie_chart.update_layout(title_x=0.5)

# Layout
app.layout = dbc.Container([
    dbc.NavbarSimple(
        brand="Fraud Detection Dashboard",
        brand_href="#",
        color="dark",
        dark=True,
        className="mb-4"
    ),
    dbc.Row([
        dbc.Col([
            dcc.Graph(figure=fraud_trend_chart)
        ], width=12)
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(figure=amount_histogram)
        ], width=6),
        dbc.Col([
            dcc.Graph(figure=device_pie_chart)
        ], width=6)
    ]),
    dbc.Row([
        dbc.Col(html.Footer(
            "© 2024 Fraud Detection System. All rights reserved.",
            className="text-center mt-4 text-muted"
        ), width=12)
    ])
], fluid=True)

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)
